package com.p7m.automator.core

import android.content.Context
import java.io.File
import java.util.Random
import java.util.UUID

data class DeviceProfile(
    val osVersion: String,
    val deviceModel: String,
    val imei: String,
    val macAddress: String,
    val androidId: String,
    val gsfId: String,
    val serialNumber: String,
    val carrierName: String,
    val iccid: String,
    val imsi: String,
    val phoneNumber: String,
    val latitude: Double,
    val longitude: Double,
    val batteryLevel: Double
)

object DeviceProfileManager {

    private val supportedModels = listOf(
        Pair("Pixel 9 Pro", "google/aiman/aiman:15/AP3A.240905.015.A2/12345678:user/release-keys"),
        Pair("Pixel 8", "google/shiba/shiba:14/AP1A.240505.005/11698712:user/release-keys"),
        Pair("Galaxy S24", "samsung/e1s/e1s:14/UP1A.231005.007/S921BXXU1AXBG:user/release-keys")
    )

    private val carriers = listOf(
        Triple("T-Mobile", "310", "260"),
        Triple("AT&T", "310", "410"),
        Triple("Verizon", "311", "480")
    )

    fun randomizeAndSaveProfile(context: Context): DeviceProfile {
        val random = Random()
        val modelPair = supportedModels.random()
        val carrier = carriers.random()

        val imei = generateValidIMEI("864102")
        val macAddress = String.format("%02x:%02x:%02x:%02x:%02x:%02x", 
            random.nextInt(256), random.nextInt(256), random.nextInt(256), 
            random.nextInt(256), random.nextInt(256), random.nextInt(256))
        
        val androidId = UUID.randomUUID().toString().replace("-", "").substring(0, 16)
        val gsfId = Math.abs(random.nextLong()).toString(16)
        val serialNumber = UUID.randomUUID().toString().uppercase().substring(0, 10)

        val iccid = "89${carrier.second}${carrier.third}" + (1..10).map { random.nextInt(10) }.joinToString("")
        val imsi = carrier.second + carrier.third + (1..10).map { random.nextInt(10) }.joinToString("")
        val phoneNumber = "+1" + (200..999).random().toString() + (1000000..9999999).random().toString()

        val latitude = 40.7128 + (random.nextDouble() - 0.5) * 0.05
        val longitude = -74.0060 + (random.nextDouble() - 0.5) * 0.05
        val batteryLevel = 0.75 + (random.nextDouble() * 0.20)

        val profile = DeviceProfile(
            osVersion = "15",
            deviceModel = modelPair.first,
            imei = imei,
            macAddress = macAddress,
            androidId = androidId,
            gsfId = gsfId,
            serialNumber = serialNumber,
            carrierName = carrier.first,
            iccid = iccid,
            imsi = imsi,
            phoneNumber = phoneNumber,
            latitude = latitude,
            longitude = longitude,
            batteryLevel = batteryLevel
        )

        populateNativeActivityStorage(context)
        return profile
    }

    private fun generateValidIMEI(tac: String): String {
        val random = Random()
        val serial = String.format("%06d", random.nextInt(999999))
        val base = tac + serial
        var sum = 0
        for (i in base.indices) {
            var digit = Character.getNumericValue(base[i])
            if (i % 2 == 1) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
        }
        val checksum = (10 - (sum % 10)) % 10
        return base + checksum
    }

    private fun populateNativeActivityStorage(context: Context) {
        val rootDir = File(context.filesDir, "system_storage_cache")
        if (rootDir.exists()) rootDir.deleteRecursively()
        rootDir.mkdirs()

        val subFolders = listOf("Downloads", "Documents", "DCIM", "Android/data/com.google.android.gm")
        val sampleNames = listOf("invoice_statement.pdf", "travel_itinerary.pdf", "family_snapshot.jpg", "app_config_backup.bin")
        
        val random = Random()
        for (folderName in subFolders) {
            val folder = File(rootDir, folderName)
            folder.mkdirs()
            for (i in 0..(2..5).random()) {
                val file = File(folder, "${System.currentTimeMillis()}_${sampleNames.random()}")
                file.writeText("NATIVE_FIRMWARE_TELEMETRY_DATA_${UUID.randomUUID()}")
                file.setLastModified(System.currentTimeMillis() - random.nextLong(86400000L * 60))
            }
        }
    }
}
