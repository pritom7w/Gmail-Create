package com.p7m.automator.net

import android.content.Context
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import java.net.Authenticator
import java.net.PasswordAuthentication

object IpConnectManager {

    var isEnabled: Boolean = false
    var host: String = ""
    var port: Int = 8080
    var proxyType: String = "HTTP" // HTTP or SOCKS5
    var username: String = ""
    var password: String = ""

    fun applyProxyConfiguration(context: Context) {
        if (!isEnabled || host.isBlank() || port <= 0) {
            clearProxyConfiguration(context)
            return
        }

        // 1. Set global proxy authentication credentials if provided
        if (username.isNotBlank() && password.isNotBlank()) {
            Authenticator.setDefault(object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(username, password.toCharArray())
                }
            })
        }

        // 2. Format proxy rule for Android WebView ProxyController
        val scheme = if (proxyType.equals("SOCKS5", ignoreCase = true)) "socks" else "http"
        val proxyRule = "$scheme://$host:$port"

        // 3. Override WebView network traffic globally across the app
        if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            val proxyConfig = ProxyConfig.Builder()
                .addProxyRule(proxyRule)
                .build()

            val executor = ContextCompat.getMainExecutor(context)
            ProxyController.getInstance().setProxyOverride(proxyConfig, executor, {
                // Proxy override applied successfully
            })
        }

        // 4. Set Java system properties for fallback network connections
        System.setProperty("http.proxyHost", host)
        System.setProperty("http.proxyPort", port.toString())
        System.setProperty("https.proxyHost", host)
        System.setProperty("https.proxyPort", port.toString())
    }

    fun clearProxyConfiguration(context: Context) {
        isEnabled = false
        Authenticator.setDefault(null)

        // Clear WebView proxy override, reverting to default device IP
        if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            val executor = ContextCompat.getMainExecutor(context)
            ProxyController.getInstance().clearProxyOverride(executor, {
                // Proxy cleared, using default connection
            })
        }

        System.clearProperty("http.proxyHost")
        System.clearProperty("http.proxyPort")
        System.clearProperty("https.proxyHost")
        System.clearProperty("https.proxyPort")
    }
}
