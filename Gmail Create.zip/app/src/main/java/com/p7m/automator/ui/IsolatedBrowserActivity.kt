package com.p7m.automator.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.p7m.automator.webview.AutomationWebViewClient

class IsolatedBrowserActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        webView = WebView(this).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            userAgentString = "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP3A.240905.015.A2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
            cacheMode = WebSettings.LOAD_NO_CACHE
            setGeolocationEnabled(false)
        }

        val isAutoEnabled = intent.getBooleanExtra("EXTRA_AUTO_ENABLED", true)
        val firstName = intent.getStringExtra("EXTRA_FIRST_NAME") ?: "Alex"
        val lastName = intent.getStringExtra("EXTRA_LAST_NAME") ?: "Gould"
        val targetUsername = intent.getStringExtra("EXTRA_USERNAME") ?: "alexgould537acx"

        webView.webViewClient = AutomationWebViewClient(
            isAutoEnabled = isAutoEnabled,
            firstName = firstName,
            lastName = lastName,
            targetUsername = targetUsername,
            onPasswordReady = { generatedPassword ->
                // Password callback hook
            }
        )

        webView.loadUrl("https://accounts.google.com/signup/v2/webcreateaccount")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
