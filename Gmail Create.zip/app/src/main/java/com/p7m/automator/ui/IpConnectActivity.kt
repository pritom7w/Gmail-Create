package com.p7m.automator.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.p7m.automator.R
import com.p7m.automator.net.IpConnectManager

class IpConnectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ip_connect)

        val switchIpToggle = findViewById<Switch>(R.id.switchIpToggle)
        val etHost = findViewById<EditText>(R.id.etHost)
        val etPort = findViewById<EditText>(R.id.etPort)
        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnSaveIpConfig = findViewById<Button>(R.id.btnSaveIpConfig)

        // Pre-fill fields with current manager state
        switchIpToggle.isChecked = IpConnectManager.isEnabled
        etHost.setText(IpConnectManager.host)
        if (IpConnectManager.port > 0) etPort.setText(IpConnectManager.port.toString())
        etUsername.setText(IpConnectManager.username)
        etPassword.setText(IpConnectManager.password)

        btnSaveIpConfig.setOnClickListener {
            IpConnectManager.isEnabled = switchIpToggle.isChecked
            IpConnectManager.host = etHost.text.toString().trim()
            IpConnectManager.port = etPort.text.toString().toIntOrNull() ?: 0
            IpConnectManager.username = etUsername.text.toString().trim()
            IpConnectManager.password = etPassword.text.toString().trim()

            if (IpConnectManager.isEnabled) {
                IpConnectManager.applyProxyConfiguration(this)
                Toast.makeText(this, "IP Connect ENABLED: All traffic routed through proxy.", Toast.LENGTH_SHORT).show()
            } else {
                IpConnectManager.clearProxyConfiguration(this)
                Toast.makeText(this, "IP Connect DISABLED: Using default network IP.", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }
}
