package com.p7m.automator.webview

import android.webkit.WebView
import android.webkit.WebViewClient
import com.p7m.automator.core.TrustEnhancer

class AutomationWebViewClient(
    private val isAutoEnabled: Boolean,
    private val firstName: String,
    private val lastName: String,
    private val targetUsername: String,
    private val onPasswordReady: (String) -> Unit
) : WebViewClient() {

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        
        // 1. Inject advanced hardware trust spoofing (WebGL, Battery, Concurrency) on every page load
        TrustEnhancer.injectAdvancedTrustSpoofing(view)

        // 2. If Auto Mode is turned OFF, stop here for manual entry
        if (!isAutoEnabled) return

        // 3. Execute sub-100ms form filling for Google signup pages
        if (url.contains("accounts.google.com")) {
            val script = """
                (function() {
                    function setVal(selector, value) {
                        let el = document.querySelector(selector);
                        if (el) {
                            el.focus();
                            el.value = value;
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }

                    // Page 1: Name & DOB (Year fixed to 1993)
                    if (document.getElementById('firstName')) {
                        setVal('input[name="firstName"]', '$firstName');
                        setVal('input[name="lastName"]', '$lastName');
                        
                        let month = document.getElementById('month');
                        if(month) { month.value = "6"; month.dispatchEvent(new Event('change')); }
                        setVal('input[name="day"]', "15");
                        setVal('input[name="year"]', "1993");
                        
                        setTimeout(() => {
                            let next = document.getElementById('collectNameNext');
                            if(next) next.click();
                        }, 25);
                    }

                    // Page 2: Username Selection
                    let userIn = document.querySelector('input[type="email"]');
                    if (userIn && !userIn.value) {
                        setVal('input[type="email"]', '$targetUsername');
                        setTimeout(() => {
                            let next = document.getElementById('next');
                            if(next) next.click();
                        }, 25);
                    }

                    // Page 3: Password Page
                    let passIn = document.querySelector('input[name="Passwd"]');
                    if (passIn && !passIn.value) {
                        let genPass = 'P7m!' + Math.random().toString(36).slice(-8) + '9';
                        setVal('input[name="Passwd"]', genPass);
                        setVal('input[name="PasswdAgain"]', genPass);
                        window.AndroidBridge?.passReady(genPass);
                    }
                })();
            """.trimIndent()
            view.evaluateJavascript(script, null)
        }
    }
}
