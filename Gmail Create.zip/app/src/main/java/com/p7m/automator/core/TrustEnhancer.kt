package com.p7m.automator.core

import android.webkit.WebView

object TrustEnhancer {

    fun injectAdvancedTrustSpoofing(webView: WebView) {
        val trustScript = """
            (function() {
                // 1. Spoof WebGL GPU Vendor & Renderer to match Pixel 9 Pro (ARM Immortalis / Mali G720)
                try {
                    const getParameterOriginal = WebGLRenderingContext.prototype.getParameter;
                    WebGLRenderingContext.prototype.getParameter = function(parameter) {
                        // UNMASKED_VENDOR_WEBGL
                        if (parameter === 37445) return 'Google Inc. (ARM)';
                        // UNMASKED_RENDERER_WEBGL
                        if (parameter === 37446) return 'ANGLE (Google, Vulkan 1.3.0 (Mali-G720), SwiftShader)';
                        return getParameterOriginal.apply(this, arguments);
                    };
                    
                    if (window.WebGL2RenderingContext) {
                        const getParameterOriginal2 = WebGL2RenderingContext.prototype.getParameter;
                        WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                            if (parameter === 37445) return 'Google Inc. (ARM)';
                            if (parameter === 37446) return 'ANGLE (Google, Vulkan 1.3.0 (Mali-G720), SwiftShader)';
                            return getParameterOriginal2.apply(this, arguments);
                        };
                    }
                } catch (e) {}

                // 2. Emulate Native Battery Manager API (Prevents undefined/desktop detection)
                if (navigator.getBattery) {
                    navigator.getBattery = function() {
                        return Promise.resolve({
                            charging: true,
                            chargingTime: 0,
                            dischargingTime: Infinity,
                            level: 0.88,
                            addEventListener: function() {},
                            removeEventListener: function() {}
                        });
                    };
                }

                // 3. Spoof Hardware Concurrency & Device Memory (Pixel 9 Pro specs)
                Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
                Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
                Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 5 });

                // 4. Clean Automation Artifacts (Hide WebDriver / Selenium flags)
                delete navigator.__defineGetter__;
                Object.defineProperty(navigator, 'webdriver', { get: () => false });
            })();
        """.trimIndent()

        webView.evaluateJavascript(trustScript, null)
    }
}
