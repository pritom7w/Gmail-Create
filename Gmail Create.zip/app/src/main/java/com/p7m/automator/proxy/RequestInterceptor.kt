package com.p7m.automator.proxy

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedQueue

data class TrafficRecord(val timestamp: String, val method: String, val endpoint: String, val payload: String?)

object RequestInterceptor {
    private val trafficLogs = ConcurrentLinkedQueue<TrafficRecord>()

    fun recordTraffic(method: String, endpoint: String, payload: String? = null) {
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        trafficLogs.add(TrafficRecord(time, method, endpoint, payload))
    }

    fun exportTrafficLogs(context: Context): File {
        val exportFile = File(context.getExternalFilesDir(null), "intercepted_traffic_${System.currentTimeMillis()}.txt")
        exportFile.bufferedWriter().use { writer ->
            for (record in trafficLogs) {
                writer.write("[${record.timestamp}] ${record.method} -> ${record.endpoint}\nPayload: ${record.payload}\n${'-'.repeat(40)}\n")
            }
        }
        return exportFile
    }

    fun clearLogs() {
        trafficLogs.clear()
    }
}
