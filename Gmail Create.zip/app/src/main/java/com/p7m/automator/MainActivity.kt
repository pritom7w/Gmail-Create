package com.p7m.automator

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.p7m.automator.core.DeviceProfileManager
import com.p7m.automator.ui.IpConnectActivity
import com.p7m.automator.ui.IsolatedBrowserActivity
import com.p7m.automator.utils.ClearDataUtils

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        val btnMenuToggle = findViewById<ImageButton>(R.id.btnMenuToggle)
        val btnOpenBrowser = findViewById<Button>(R.id.btnOpenBrowser)
        val btnClearAllData = findViewById<Button>(R.id.btnClearAllData)
        val btnRandomizedAll = findViewById<Button>(R.id.btnRandomizedAll)

        // Left Arrow / Menu Drawer Toggle Trigger
        btnMenuToggle.setOnClickListener {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                drawerLayout.openDrawer(GravityCompat.START)
            }
        }

        // Option 1: Open Browser
        btnOpenBrowser.setOnClickListener {
            val intent = Intent(this, IsolatedBrowserActivity::class.java).apply {
                putExtra("EXTRA_AUTO_ENABLED", true)
                putExtra("EXTRA_FIRST_NAME", "Alex")
                putExtra("EXTRA_LAST_NAME", "Gould")
                putExtra("EXTRA_USERNAME", "alexgould537acx")
            }
            startActivity(intent)
        }

        // Option 2: Clear All Data
        btnClearAllData.setOnClickListener {
            ClearDataUtils.clearAllBrowserData(this, null)
            Toast.makeText(this, "All browser session data cleared!", Toast.LENGTH_SHORT).show()
        }

        // Option 3: Randomized All
        btnRandomizedAll.setOnClickListener {
            DeviceProfileManager.randomizeAndSaveProfile(this)
            Toast.makeText(this, "Everything randomized with fresh trust reputation profile!", Toast.LENGTH_SHORT).show()
        }

        // Sidebar Navigation Click Handlers
        findViewById<Button>(R.id.navIpConnect).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, IpConnectActivity::class.java))
        }

        findViewById<Button>(R.id.navInterceptor).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            Toast.makeText(this, "Opening Live Request Interceptor...", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.navSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            Toast.makeText(this, "Opening Settings Menu...", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.navFileManager).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            Toast.makeText(this, "Opening Native Storage File Manager...", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.navExit).setOnClickListener {
            finishAffinity()
        }
    }
}
