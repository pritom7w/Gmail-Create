package com.p7m.automator.utils

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import java.io.File

object ClearDataUtils {
    fun clearAllBrowserData(context: Context, webView: WebView?) {
        webView?.let {
            it.clearCache(true)
            it.clearHistory()
            it.loadUrl("about:blank")
        }
        
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()

        try {
            val cacheDir = context.cacheDir
            if (cacheDir.exists()) cacheDir.deleteRecursively()
            
            val appDir = File(context.filesDir.parentPath!!)
            appDir.list()?.forEach { filename ->
                if (filename != "lib") {
                    File(appDir, filename).deleteRecursively()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
