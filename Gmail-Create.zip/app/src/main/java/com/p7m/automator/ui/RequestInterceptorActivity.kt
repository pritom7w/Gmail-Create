package com.p7m.automator.ui

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.p7m.automator.R
import com.p7m.automator.proxy.RequestInterceptor
import java.io.File

class RequestInterceptorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interceptor)

        val logTextView = findViewById<TextView>(R.id.txtLogs)
        val exportedFile: File = RequestInterceptor.exportTrafficLogs(this)
        
        if (exportedFile.exists()) {
            logTextView.text = exportedFile.readText().ifEmpty { "No HTTP traffic intercepted yet." }
        } else {
            logTextView.text = "No logs recorded."
        }

        findViewById<Button>(R.id.btnClearLogs)?.setOnClickListener {
            RequestInterceptor.clearLogs()
            logTextView.text = "Logs cleared."
        }

        findViewById<Button>(R.id.btnBackInterceptor)?.setOnClickListener { finish() }
    }
}
