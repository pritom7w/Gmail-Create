package com.p7m.automator.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.p7m.automator.R
import java.io.File

class FileManagerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_manager)

        val listView = findViewById<ListView>(R.id.fileListView)
        val fileList = mutableListOf<String>()

        fun loadFiles(dir: File) {
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) {
                    loadFiles(file)
                } else {
                    fileList.add(file.absolutePath.replace(filesDir.absolutePath, ""))
                }
            }
        }

        loadFiles(filesDir)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, fileList)
        listView.adapter = adapter

        findViewById<Button>(R.id.btnBackFiles)?.setOnClickListener { finish() }
    }
}
