package com.p7m.automator.ui

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.p7m.automator.R
import com.p7m.automator.utils.ClearDataUtils

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<Button>(R.id.btnClearCacheData)?.setOnClickListener {
            ClearDataUtils.clearAllBrowserData(this, null)
            Toast.app(this, "All App & Browser Data Cleared!", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnBackSettings)?.setOnClickListener {
            finish()
        }
    }
}
